using UnityEngine;
using UnityEngine.SceneManagement;

public class GameEndController : MonoBehaviour
{
    public GameObject winPanel;
    public GameObject losePanel;
    public string mainMenuSceneName = "MenuPrincipal";
    public TCPClient tcpClient;
    public bool isHost = false;
    private bool gameEnded = false;

    private void Start()
    {
        if (winPanel != null) winPanel.SetActive(false);
        if (losePanel != null) losePanel.SetActive(false);
        if (tcpClient == null) tcpClient = FindFirstObjectByType<TCPClient>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (gameEnded) return;

        string enteringId = GetPlayerIdFromCollider(other);
        if (string.IsNullOrEmpty(enteringId)) return;

        if (!IsLocalPlayer(enteringId)) return;

        gameEnded = true;
        DeclareWinner(enteringId);
    }

    private string GetPlayerIdFromCollider(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            var cp = other.GetComponent<ClientPlayer>();
            if (cp != null)
            {
                var idField = cp.GetType().GetField("playerId");
                if (idField != null)
                    return idField.GetValue(cp)?.ToString();
                if (!string.IsNullOrEmpty(ClientPlayer.LocalClientId))
                    return ClientPlayer.LocalClientId;
            }

            var hp = other.GetComponent<HostPlayer>();
            if (hp != null)
            {
                var idField = hp.GetType().GetField("playerId");
                if (idField != null)
                    return idField.GetValue(hp)?.ToString();
            }
        }
        return null;
    }

    private bool IsLocalPlayer(string id)
    {
        if (string.IsNullOrEmpty(id)) return false;
        if (!string.IsNullOrEmpty(ClientPlayer.LocalClientId))
            return ClientPlayer.LocalClientId == id;
        var hostPlayer = FindFirstObjectByType<HostPlayer>();
        if (hostPlayer != null && isHost)
        {
            var idField = hostPlayer.GetType().GetField("playerId");
            if (idField != null)
            {
                var value = idField.GetValue(hostPlayer)?.ToString();
                return value == id;
            }
        }
        return false;
    }

    private void DeclareWinner(string winnerId)
    {
        if (string.IsNullOrEmpty(winnerId)) return;

        if (isHost)
        {
            BroadcastWinToAll(winnerId);
        }
        else
        {
            if (tcpClient != null)
            {
                tcpClient.Send($"{winnerId}|WIN");
            }
        }
    }

    public void OnReceiveWinner(string winnerId)
    {
        gameEnded = true;
        if (ClientPlayer.LocalClientId == winnerId)
        {
            ShowWin();
        }
        else
        {
            ShowLose();
        }
    }

    private void ShowWin()
    {
        if (winPanel != null) winPanel.SetActive(true);
        Time.timeScale = 0f;
    }

    private void ShowLose()
    {
        if (losePanel != null) losePanel.SetActive(true);
        Time.timeScale = 0f;
    }

    public void ReturnToMainMenu()
    {
        Time.timeScale = 1f;
        try
        {
            if (tcpClient != null) tcpClient.Disconnect();
        }
        catch { }
        SceneManager.LoadScene(mainMenuSceneName);
    }

    private void BroadcastWinToAll(string winnerId)
    {
        if (tcpClient == null) return;
        tcpClient.Send($"WINNER|{winnerId}");
        OnReceiveWinner(winnerId);
    }
}