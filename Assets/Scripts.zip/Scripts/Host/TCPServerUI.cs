// TCPServerUI.cs
using UnityEngine;

public class TCPServerUI : MonoBehaviour
{
    public int serverPort = 5555;
}