// TCPClientUI.cs
using UnityEngine;

public class TCPClientUI : MonoBehaviour
{
    public string serverAddress = "127.0.0.1";
    public int serverPort = 5555;
}